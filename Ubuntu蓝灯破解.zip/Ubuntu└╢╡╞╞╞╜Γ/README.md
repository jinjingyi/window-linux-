1.安装lantern

```shell
sudo dpkg -i lantern-installer-64-bit.deb
```

2.每月500M免费高速流量，用完后请看`更改mac.md`